package com.nfl.nfl_zone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NflZoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
