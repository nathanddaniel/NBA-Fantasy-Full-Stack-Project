package com.nfl.nfl_zone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NflZoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(NflZoneApplication.class, args);
	}

}
