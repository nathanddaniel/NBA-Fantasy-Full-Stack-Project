package com.nba.fantasy_hoopz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FantasyHoopzApplicationTests {

	@Test
	void contextLoads() {
	}

}
