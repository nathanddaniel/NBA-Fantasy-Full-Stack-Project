package com.nba.fantasy_hoopz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FantasyHoopzApplication {

	public static void main(String[] args) {
		SpringApplication.run(FantasyHoopzApplication.class, args);
	}

}
